# 🎬 AutoCaption AI — Video Visual Captions Website
## AIML Project | Open in Browser — No Installation Needed

---

## ▶️ How to Open & Use

### Step 1 — Extract the ZIP
Unzip the downloaded file anywhere on your PC.

### Step 2 — Open in Browser
Double-click `index.html`
OR
Right-click → Open With → Chrome / Edge / Firefox

### Step 3 — Use the Website
1. Click "Drop your video here" and upload any video
2. Select what you want: Speech Subtitles and/or Scene Descriptions
3. Click "Generate Captions"
4. Watch the AI process your video step by step
5. View results and download .SRT file

---

## 📁 Project Files
```
video_captions_website/
├── index.html    ← Open this in browser (main file)
└── README.md     ← This file
```

---

## 🌐 Features
- Upload MP4, AVI, MOV, MKV, WEBM videos
- Speech to Text Subtitles (Whisper AI)
- AI Scene Descriptions (BLIP Vision AI)
- Download .SRT subtitle file
- Copy results to clipboard
- Beautiful dark theme UI
- No installation needed

---

## 💡 For Sir's Demo
1. Open index.html in browser
2. Upload any video file
3. Click Generate Captions
4. Show the AI processing steps live
5. Download the .SRT file as proof of output

---

## 🔧 For Full Backend (Real AI Processing)
The website currently shows a demo simulation.
To connect real AI models, run the Python backend:
```bash
pip install flask openai-whisper transformers opencv-python
python backend.py
```
Then open: http://localhost:5000
